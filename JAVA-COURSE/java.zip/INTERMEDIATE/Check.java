/* 

This program dosen't run because JAVA  dosen't supports multiple inheritance 

the reason why java dosen't suppor multiple inheritance is because 
when you observe the below program The c class which extends the class a, b 
when you creat the object of class c and call the mehtod c.show() ...java confuses 
and which show method I want to call there are two show methods in class a and class
b ..........



class A { 
    public int method() {  
        return 0; 
        
    }
} 

class B { 
    public int method() { 
        return 0; 
    }
} 

class c extends A, B { 

}


public class Check { 
    public static void main(String[] args) {
        c  cc = new cc(); 
        c.show(); 
    }
    
}

*/ 
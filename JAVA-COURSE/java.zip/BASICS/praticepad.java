class thor {  

    thor data; 
    
    
    

}



class praticepad { 
    public static void main(String[] args) { 

        thor th = new thor();
        
    } 
}
public class CaseSwitch { 
    public static void main(String[] args) {
        //int a = 3;  
        String b = "sirisha"; 

        switch(b) { 

            case "sasi" : 
                System.out.println("One"); 
                break; 

            case "sirisha" :  
                System.out.println("siri");   
                break ; 

            case "3": 
                System.out.println("three");  
                break ; 

            default : 
                System.out.println("None"); 
                break ; 


        }
    }
    
}
public class Ternary { 
    public static void main(String[] args) {
        // ternary operator  

        int k = 90 ; 

        /*if(k%2==0) System.out.println("Even number"); 
        else System.out.println("odd");  */

        // condition? condition1: condition2 

        int res = k >= 90 ? 45 : 900;   

        System.out.println(res); 
         
    }
}
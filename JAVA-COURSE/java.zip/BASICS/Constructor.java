class cons {  

    public cons() { 
        int i = 5; 
        int j = 67; 
        int res = i+j; 
        System.out.println(res); 
    
    }  
    public void render() { 

    }

  

}

public class Constructor { 
    public static void main(String[] args) { 
        cons c = new cons();  
        c.render();
        
    }
    
}
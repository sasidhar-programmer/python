class calc {    

    // method 
    public int add(int a , int b) {    
      
        return a+b; 
    }

}

public class Oops_1 { 

    public static void main(String[] args) { 

        calc cal = new calc();  
        System.out.println(cal.add(55, 55)); 
       
        
    }
    
}
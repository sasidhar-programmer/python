

class Arrays { 

    public Arrays() { 
        System.out.println("demo");
    }
}


public class OnedArray2 { 
    public static void main(String[] args) {  
        Arrays a1 = new Arrays();  
        Arrays a2 = new Arrays(); 
        Arrays a3 = new Arrays(); 
        Arrays a4 = new Arrays(); 
        Arrays a5 = new Arrays(); 

        Arrays a[] = new Arrays[5];   
        Arrays b[] = {a1, a2, a3, a4, a5}; 
        
    }
    
}
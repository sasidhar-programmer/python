public class DoWhile { 
    public static void main(String[] args) {
        int i = 2888; 
        // do while loop runs loop one time even the condition is false 

        do { 
            System.out.println("Test case of do while loop"); 
            i++; 
        } while(i<=30); 
    }
    
}